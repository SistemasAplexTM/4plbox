<template lang="html">
  <div class="">
    <div class="mail-box-header">
        <h2>
            Formatos de número
        </h2>
    </div>
    <div class="mail-box">
      <form class="form-horizontal" action="#">
        <div class="form-group">
          <label for="" class="col-lg-2">Separador</label>
          <div class="col-lg-3">
            <input type="text" class="form-control">
          </div>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
export default {
}
</script>

<style lang="css">
</style>
