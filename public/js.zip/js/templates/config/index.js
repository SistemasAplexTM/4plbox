var objVue = new Vue({
    el: '#aplexConfig',
})