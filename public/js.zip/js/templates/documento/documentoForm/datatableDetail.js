export function datatableDetail(){
    //     if ($.fn.DataTable.isDataTable('#whgTable')) {
    // var table = $('#whgTable').DataTable();
    //     table.clear();
    //         $('#whgTable tbody').empty();
    //         $('#whgTable').dataTable().fnDestroy();
    //     }
    $('#whgTable').DataTable({
        ajax: 'getDataDetailDocument',
        // "paging":   false,
        // "info":     false,
        processing: false,
        serverSide: false,
        "searching": false,
        // "order": [[ 0, "desc" ], [ 1, "desc" ]],
        columns: [{
            data: 'num_warehouse',
            name: 'num_warehouse'
        }, {
            "render": function (data, type, full, meta) {
                return '<a data-name="piezas" data-pk="'+full.id+'" data-value="'+full.piezas+'" class="td_edit" data-type="text" data-placement="right" data-title="Piezas">'+full.piezas+'</a>';
            }
        },  {
            "render": function (data, type, full, meta) {
                var cadena  = full.dimensiones;
                var dimensiones = cadena.split(" ");
                var arr1 = cadena.split("=");
                var arrF = arr1[1].split("x");
                return '<a data-name="peso" data-pk="'+full.id+'" class="td_edit" data-type="text" data-placement="right" data-title="Peso">'+full.peso+'</a> ' +
                ' <a data-name="dimensiones" data-pk="'+full.id+'" data-value="'+arrF+'" class="td_edit_d" data-type="address" data-placement="right" data-title="Dimensiones">'+dimensiones[1]+'</a>';;
            }
        }, {
            "render": function (data, type, full, meta) {
                return '<a data-name="contenido" data-pk="'+full.id+'" data-value="'+full.contenido+'" class="td_edit" data-type="text" data-placement="right" data-title="Contenido">'+full.contenido+'</a>';
            }
        }, {
            "render": function (data, type, full, meta) {
                var pa = full.nom_pa;
                return ((pa === null) ? '' : pa) + '<a  data-toggle="tooltip" title="Canbiar" class="edit" style="float:right;color:#FFC107;" onclick="showModalArancel('+full.id+', \'whgTable\')"><i class="fal fa-pencil"></i></a>';
            },
            visible: (objVue.mostrar.includes(16)) ? true : false
        },
        {
            "render": function (data, type, full, meta) {
                return '<a data-name="declarado" data-pk="'+full.id+'" class="td_edit" data-type="text" data-placement="left" data-title="Declarado">'+full.valor+'</a>';
            }
        }, {
            sortable: false,
            "render": function(data, type, full, meta) {
                var btn_addTracking = '';
                var btn_edit = '';
                var btn_save = '';
                var btn_delete = '';
                var display = 'inline-block';
                if(full.consolidado == 1){
                    display = 'none';
                }

                btn_addTracking = '<a class="btn btn-info btn-xs btn-actions addTrackings" type="button" id="btn_addtracking'+full.id+'" data-toggle="tooltip" title="Agregar tracking" onclick="addTrackings('+full.id+')"><i class="fa fa-truck"></i> <span id="cant_tracking'+full.id+'">'+full.cantidad+'</span></a> ';

                btn_save = '<a class="btn btn-primary btn-xs btn-actions" type="button" id="btn_confirm'+full.id+'" onclick="saveTableDetail('+full.id+')" data-toggle="tooltip" title="Guardar" style="display:none;"><i class="fa fa-check"></i></a> ';

                btn_edit = '<a class="btn btn-success btn-xs btn-actions" type="button" id="btn_edit'+full.id+'" onclick="editTableDetail('+full.id+')" data-toggle="tooltip" title="Editar"><i class="fa fa-edit"></i></a> ';

                btn_delete = '<a class="btn btn-danger btn-xs btn-actions" type="button" id="btn_remove'+full.id+'" onclick="eliminar('+full.id+', false)" data-toggle="tooltip" title="Eliminar" style="display: '+display+'"><i class="fa fa-times"></i></a> ';

                return btn_addTracking + btn_delete;
            }
        }, {
            data: 'volumen',
            name: 'volumen',
            visible: false
        }, {
            data: 'piezas',
            name: 'piezas',
            visible: false
        }, {
            data: 'peso',
            name: 'peso',
            visible: false
        }, {
            data: 'valor',
            name: 'valor',
            visible: false
        },],
        "drawCallback": function () {
            /* EDITABLE FIELD */
            // if (me.permissions.editDetail) {
                $(".td_edit").editable({
                    ajaxOptions: {
                        type: 'post',
                        dataType: 'json'
                    },
                    url: "updateDetailDocument",
                    validate:function(value){
                        if($.trim(value) == ''){
                            return 'Este campo es obligatorio!';
                        }
                    },
                    success: function(response, newValue) {
                        refreshTable('whgTable');
                        objVue.totalizeDocument();
                    }
                });

                $('.td_edit_d').editable({
                    ajaxOptions: {
                        type: 'post',
                        dataType: 'json'
                    },
                    mode: 'popup',
                    url: 'updateDetailDocument',
                    validate:function(value){
                        if($.trim(value.largo) == '' || $.trim(value.ancho) == '' || $.trim(value.alto) == ''){
                            return 'Los campos no pueden ir vacios!';
                        }
                    },
                    success: function(response, newValue) {
                        refreshTable('whgTable');
                        objVue.totalizeDocument();
                    }
                });
            // }
        },
        "footerCallback": function (row, data, start, end, display) {
            var api = this.api(), data;
            /*Remove the formatting to get integer data for summation*/
            var intVal = function (i) {
                return typeof i === 'string' ?
                        i.replace(/[\$,]/g, '') * 1 :
                        typeof i === 'number' ?
                        i : 0;
            };
            /*Total over all pages*/
            var vol = api
                    .column(7)
                    .data()
                    .reduce(function (a, b) {
                        return intVal(Math.ceil(a)) + intVal(Math.ceil(b));
                    }, 0);
            var piezas = api
                    .column(8)
                    .data()
                    .reduce(function (a, b) {
                        return intVal(a) + intVal(b);
                    }, 0);
            var peso = api
                    .column(9)
                    .data()
                    .reduce(function (a, b) {
                        return intVal(Math.ceil(a)) + intVal(Math.ceil(b));
                    }, 0);
            var dec = api
                    .column(10)
                    .data()
                    .reduce(function (a, b) {
                        return intVal(a) + intVal(b);
                    }, 0);

            /*Update footer formatCurrency()*/
            $('#piezas').val(parseFloat(isInteger(piezas)));
            $('#volumen').val(parseFloat(isInteger(Math.ceil(vol))));
            $('#pie_ft').val(parseFloat(isInteger(Math.ceil(vol * 166 / 1728))));
            $('#pesoDim').val(parseFloat(isInteger(peso)));
            $('#valor_declarado_tbl').val(parseFloat(isInteger(dec)));
        },
    }).on('xhr.dt', function ( e, settings, json, xhr ) {
        if(app_type === 'courier'){
            if(json.data.length === 0){
                objVue.cantidad_detalle = true;
                // $('#btn_add').attr('disabled', false);
                // $('#btn_add').siblings('button').attr('disabled', false);
            }else{
                objVue.cantidad_detalle = false;
                // $('#btn_add').attr('disabled', true);
                // $('#btn_add').siblings('button').attr('disabled', true);
            }
        }
        objVue.totalizeDocument();
        // console.log(json.data);
    });
}
