$(document).ready(function() {

});

var objVue = new Vue({
    el: '#minuta',
    data: {
        name: null,
    },
    methods: {
        //
    },
});