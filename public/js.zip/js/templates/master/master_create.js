new Vue({
 el: '#master',
 data:{
   
 },
 methods: {
  
	}
});