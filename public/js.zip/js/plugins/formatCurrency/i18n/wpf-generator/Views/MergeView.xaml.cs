﻿using System.Windows.Controls;

namespace wpf_generator.Views
{
    /// <summary>
    /// Interaction logic for MergeView.xaml
    /// </summary>
    public partial class MergeView : UserControl
    {
        public MergeView()
        {
            InitializeComponent();
        }
    }
}
